from django.apps import AppConfig


class PrintnameConfig(AppConfig):
    name = 'printname'
